namespace NetKubernetes.Dtos.CategoryDtos;


public class CategoryResponseDto {

  public int Id { get; set; }

    public string? Nombre { get; set; }

    public string? ImageUrl { get; set; }

}