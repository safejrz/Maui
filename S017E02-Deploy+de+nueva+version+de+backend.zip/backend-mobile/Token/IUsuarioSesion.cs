namespace NetKubernetes.Token;

public interface IUsuarioSesion {

    string ObtenerUsuarioSesion();
}